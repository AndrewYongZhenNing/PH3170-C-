#ifndef _functions_
#define _functions_

void swap(int *left, int *right);

void sort(int sequence[], int length);

void merge(int main_array[], int sequence1[], int sequence1_length, int sequence2[], int sequence2_length);

#endif
