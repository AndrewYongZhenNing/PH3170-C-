#include <iostream>
#include "AYONG_PS4Q3.h"

int main(){

  std::cout << "Question 3\n" << std::endl;

  // int** M1 = new int*[3];
  //
  // for (int i = 0 ; i <3 ; i++){
  //   M1[i] = new int[3];
  // }
  //
  // delete[] M1;

  int M1[3][3] = {{2,6,1},{1,8,4},{2,9,6}};
  int M2[3][3] = {{4,7,9},{1,2,5},{2,4,3}};

  matrix_multiply(M1,M2);
}

void matrix_multiply(int matrix_1[][3], int matrix_2[][3]){

  int output_matrix[3][3] = {}; // this output_matrix will store the values from the multiplication

  std::cout << "The product of M1 and M2 are: " << std::endl;

  for (int i = 0; i < 3; i++){ // iterating through the row

    std::cout << " " << std::endl;

    for (int j = 0; j < 3; j++){ // iterating through the column

      int value = 0;

      for (int k = 0; k < 3; k++){

        value +=  matrix_1[i][k]*matrix_2[k][j]; // matrix multiplication in a general expression; new term of output_matrix calculated here
      }

      output_matrix[i][j] = value; // appended into the output_matrix

      std::cout << output_matrix[i][j] << " " << std::flush; // used std::flush here to prevent from starting a new line
                                                            // when each matrix element is printed - preserves the matrix representation
    }

    std::cout << " " << std::endl; // this line leaves gap between each printed matrix element, for a tider representation
  }

}
