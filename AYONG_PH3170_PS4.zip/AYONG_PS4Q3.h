#ifndef _functions_
#define _functions_

void matrix_multiply(int matrix_1[][3], int matrix_2[][3]);

#endif
